package com.cg.runner;


import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
			features= {"C:\\BDD MODULE TEST\\PersonalDetails\\feature-scenario\\details.Feature"}
			,glue="FormStepDef"
			,plugin= {"pretty", "html:target/ranjan-report"}
			,monochrome=true
			,dryRun=true  // to check unit step cases are there in the stepdef file or not
		
		)
public class DetailRunner {

}
 