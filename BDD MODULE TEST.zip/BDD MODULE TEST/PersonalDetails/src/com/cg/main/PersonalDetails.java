package com.cg.main;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PersonalDetails {

	 WebDriver d;
	 JavascriptExecutor js;
	 
	@Given("^open website$")
	public void open_website() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 System.setProperty("webdriver.chrome.driver", "C:\\BDD\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
		  d=new ChromeDriver();
		  d.get("C:\\BDD MODULE TEST\\set 1\\WebPages\\PersonalDetails.html");
		  d.manage().window().maximize();
	   // throw new PendingException();
	}

	@When("^Fill up the form successfully$")
	public void fill_up_the_form_successfully() throws Throwable {
		
		 try
		  {
		   //Thread.sleep(3000);
		   WebDriverWait w=new WebDriverWait(d,10);
		   w.until(ExpectedConditions.alertIsPresent());
		   
		   Alert alert=d.switchTo().alert();
		   String str=alert.getText();
		   System.out.println("alert msg="+str);
		   alert.accept();
		  }
		  catch(Exception e)
		  {
		   System.out.println("Alert has not been caught");
		  }
		
		
		 d.findElement(By.xpath("//*[@id=\"txtFirstName\"]")).sendKeys("Ranjan");
		 
		 d.findElement(By.xpath("//*[@id=\"txtLastName\"]")).sendKeys("Tyagi");
		 Thread.sleep(3000);
		  d.findElement(By.xpath("//*[@id=\"txtEmail\"]")).sendKeys("tranjan505@gmail.com");
		  
		  js=(JavascriptExecutor)d;
		  d.findElement(By.xpath("//input[@type='email']")).sendKeys("@gmail.com");
		  WebElement w=d.findElement(By.xpath("//input[@type='email']"));
		  boolean b1=(boolean)js.executeScript("return arguments[0].checkValidity();",w);
		  String message=(String)js.executeScript("return arguments[0].validationMessage;", w);
		  String m=d.findElement(By.name("Email")).getAttribute("validationMessage");
		  
		  System.out.println(m);
		  if(m.equalsIgnoreCase("Please include an '@' in the email address. 'manga' is missing an '@'."))
		  {
		   System.out.println("Pop-Message is dislayed for invalid email-NO DEFECT");
		  }
		  else
		  {
		   System.out.println("Pop-Message is not dislayed for invalid email-DEFECT");
		  }
		  
		  
		  d.findElement(By.xpath("//*[@id=\"txtPhone\"]")).sendKeys("8884555666");
		  
		  d.findElement(By.xpath("//*[@id=\"txtAddress1\"]")).sendKeys("107 Sri VishnuPriya Niwas");
		  d.findElement(By.xpath("//*[@id=\"txtAddress2\"]")).sendKeys("Gangamma Circle Bangalore");
		 
		//  Thread.sleep(3000);
		  d.findElement(By.xpath("/html/body/form/table/tbody/tr[9]/td[2]/select")).click();
		//  Thread.sleep(3000);
		  d.findElement(By.xpath("/html/body/form/table/tbody/tr[9]/td[2]/select/option[3]")).click();
		  
		  d.findElement(By.xpath("/html/body")).click();
		  
		//  Thread.sleep(3000);
		  d.findElement(By.xpath("/html/body/form/table/tbody/tr[10]/td[2]/select")).click();
		//  Thread.sleep(3000);
		  d.findElement(By.xpath("/html/body/form/table/tbody/tr[10]/td[2]/select/option[3]")).click();
		  
		  d.findElement(By.xpath("/html/body")).click();
		  
		 // Thread.sleep(5000);
		  
		  d.findElement(By.linkText("Next")).click();
		  Thread.sleep(1000);
		 // WebDriverWait w=new WebDriverWait(d,10);
		  // w.until(ExpectedConditions.alertIsPresent());
		//  Thread.sleep(5000);
		  
		  Alert alert = d.switchTo().alert();
		  alert.accept();
		  // d.findElement(By.partialLinkText("OK")).click();
		 
	    // Write code here that turns the phrase above into concrete actions
	  
	}

	@When("^Fill up next page$")
	public void fill_up_next_page() throws Throwable {
		
		  Thread.sleep(3000);
		  d.findElement(By.xpath("/html/body/form/table/tbody/tr[1]/td[2]/select")).click();
		  Thread.sleep(3000);
		  d.findElement(By.xpath("/html/body/form/table/tbody/tr[1]/td[2]/select/option[3]")).click();
		  Thread.sleep(1000);
  		  d.findElement(By.xpath("/html/body")).click();
		
  		 d.findElement(By.xpath("//*[@id=\"txtPercentage\"]")).sendKeys("81.2%");
  		 d.findElement(By.xpath("//*[@id=\"txtPassYear\"]")).sendKeys("2018");
  		 d.findElement(By.xpath("//*[@id=\"txtProjectName\"]")).sendKeys("Privacy Preserving Via Encryption");
  		  Thread.sleep(1000);
  		  d.findElement(By.xpath("//*[@id=\"cbTechnologies\"]")).click();
  		
  		d.findElement(By.xpath("/html/body")).click();
		
  		d.findElement(By.xpath("//*[@id=\"txtOtherTechs\"]")).sendKeys("HTML,Angular,Typescript");
  		Thread.sleep(1000);
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
	}

	@And("^Click on Register Me$")
	public void click_on_Register_Me() throws Throwable {
		
		
		 d.findElement(By.id("btnRegister")).click();
		
		
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
	}

	@Then("^Registration is successful$")
	public void registration_is_successful() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
	}
}
